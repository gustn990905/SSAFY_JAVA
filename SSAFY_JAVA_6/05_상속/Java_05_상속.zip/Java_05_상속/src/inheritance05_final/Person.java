package inheritance05_final;

public final class Person {
	String name;
	private int age;

	//변수에다가 final 붙여보자 => 값을 고정시킨다는 뜻 
	final String fName = "익명";
	final String fName2;
	
	
	public Person() {
		// TODO Auto-generated constructor stub
		fName2 = "익명2";
	}
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
		fName2 = "익명2";
	}


	//재정의(메서드 오버라이딩 금지)
	final void eat() {
		System.out.println("냠냠 먹는다.");
	}
	
	
}
