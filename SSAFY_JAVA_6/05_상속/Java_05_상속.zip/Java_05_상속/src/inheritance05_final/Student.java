package inheritance05_final;

import java.util.Objects;

public class Student extends Person{
	String major;
	
	//eat()메서드를 사용할 수 있는 상태
	//어디선가 외부에서 호출했다면 냠냠 먹는다. 출력이된다.
	//아래처럼 재정의 해버리면 이제 냠냠 먹지 않는다.
	//오버라이딩이라고 한다.
	//메서드의 이름, 매개변수, 반환타입 같아야한다.
	//접근제한자는 부모와 같거나 더 넓으면 OK (좁게는 안된다.)
//	@Override //어노테이션은 써주면 실수 방지에 좋음
//	public void eat() {
//		System.out.println("쓱삭쓱싹 지식을 먹는다");
//	}
	
	//아래의 친구는 메서드 오버로딩이다.
	//메서드 명이 동일 해야한다. / 매개변수의 타입순서 또는 개수가 달라야 한다.
	void eat(int time) {
		System.out.println("쓱삭쓱싹 지식을 먹는다");
	}
	
	
	
	void study() {
		System.out.println("공부를 한다.");
	}

	@Override
	public String toString() {
		return "Student [major=" + major + ", name=" + name + "]";
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
}
