package inheritance04_override;

public class Person {
	String name;
	private int age;

	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}



	void eat() {
		System.out.println("냠냠 먹는다.");
	}
	
	
}
