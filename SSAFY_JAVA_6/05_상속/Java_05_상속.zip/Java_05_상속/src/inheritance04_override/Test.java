package inheritance04_override;

public class Test {
	public static void main(String[] args) {
		Student st = new Student();

//		st.eat();
//		System.out.println(st);
		
		Object obj1 = new Object();
		Object obj2 = new Object();
		Object obj3 = obj2;
		
		System.out.println(obj1 == obj2);
		System.out.println(obj1.equals(obj2));
		System.out.println(obj2 == obj3);
		System.out.println(obj2.equals(obj3));
		
		
	}
}
