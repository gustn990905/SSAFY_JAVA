package abstract_class02_inheritance;

public class KFoodChef extends Chef{
	String speciality; //내주전공
	
//	@Override
	public void cook() {
		System.out.println("한식을 조리한다.");
	}
}
