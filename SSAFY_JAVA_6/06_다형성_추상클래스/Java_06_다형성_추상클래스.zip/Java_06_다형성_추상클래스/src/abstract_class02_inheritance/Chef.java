package abstract_class02_inheritance;

public class Chef {
	String name;
	int age;
	
	public void eat() {
		System.out.println("음식을 먹는다.");
	}
	
	//어차피 아래코드는 절대로 쓰이지는 않는데 지울까?
//	public void cook() {
//		System.out.println("음식을 조리한다.");
//	}
}
