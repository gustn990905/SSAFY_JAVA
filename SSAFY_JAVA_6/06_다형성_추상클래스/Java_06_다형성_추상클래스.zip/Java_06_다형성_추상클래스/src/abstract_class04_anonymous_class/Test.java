package abstract_class04_anonymous_class;

public class Test {
	public static void main(String[] args) {
		//추상클래스는 객체를 생성할 수 없다!
		//cook() 추상메서드가 있어서 구현이 안되어 있으니까...
		//1회한정으로 사용하려고 할떄 직접 미완성인 부분을 구현해줌으로써 사용도 가능하게 해줌
		//익명 클래스라고 한다.
		Chef chef = new Chef() {
			@Override
			public void cook() {
				System.out.println("랜덤 요리를 한다!");
			}
		};
		
		chef.eat();
		chef.cook();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
