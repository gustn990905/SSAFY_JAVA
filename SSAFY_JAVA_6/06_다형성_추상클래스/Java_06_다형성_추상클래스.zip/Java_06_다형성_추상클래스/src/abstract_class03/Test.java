package abstract_class03;

public class Test {
	public static void main(String[] args) {
		
		Chef[] chefs = new Chef[2];
		
		//조상클래스의 배열을 이용하여 자식들을 관리하겠다.
		chefs[0] = new KFoodChef();
		chefs[1] = new JFoodChef();
		
		for(Chef chef : chefs) {
			chef.eat();
			chef.cook(); //왜? 한식/일식 조리가 나오지? -> 동적바인딩에 의해
		}
		
		
		
		
		
//		Chef chef = new Chef(); //객체(인스턴스)생서할 수없음 (추클은)
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
