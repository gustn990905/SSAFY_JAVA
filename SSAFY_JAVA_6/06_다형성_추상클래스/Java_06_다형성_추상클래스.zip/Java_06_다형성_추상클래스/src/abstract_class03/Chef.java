package abstract_class03;

//객체를 생성할 수 없게 해야된다. -> 추상클래스
public abstract class Chef {
	String name;
	int age;
	public void eat() {
		System.out.println("음식을 먹는다.");
	}
	
	//구현부가 안쓰여서 미완성인채로 두자!
	//추상메서드를 정의했다!
	//Chef 클래스를 상속받는 클래스들은 cook를 재정의해야하는 강제성을 가지게 된다.
	public abstract void cook();
	//추클은 반드시 추메가 필요하니? -> X
}
