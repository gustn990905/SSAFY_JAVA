package abstract_class03;


//추상클래스를 상속 받는 경우 두가지 선택권이 생겼다.
//1. 추상메서드를 구현하기->강제성 (일반 메서드는 반드시 구현할 필요는 없음 -> 그냥 가져다 쓰면됨)
//2. 나도 추상클래스가 되어야 한다.
public class JFoodChef extends Chef{
	String speciality; //내주전공
	
	public void eat() {
		System.out.println("오물오물 먹는다.");
	}
	
	
	public void cook() {
		System.out.println("일식을 조리한다.");
	}
}
