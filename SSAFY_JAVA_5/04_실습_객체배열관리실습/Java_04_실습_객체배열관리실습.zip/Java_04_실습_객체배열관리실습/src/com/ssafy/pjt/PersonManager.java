package com.ssafy.pjt;

import java.util.Arrays;

//싱글턴패턴을 적용해보자 -> 1개만 만들어지도록
public class PersonManager {
	private final int MAX_SIZE = 10; // 상수처리(스네이크 케이스 대문자로)
	// 사람의 목록을 관리를 하겠다.
	private Person[] arr = new Person[MAX_SIZE];
	private int size = 0; // 용도를 생각해보즈아~~

	// 1번: 외부에서 생성하지 못하게 해야해~
	// 기본생성자의 접근제한자를 private 으로 바꾼다.
	private PersonManager() {
	}

	// 2번: 외부에서 생성하지 못하니까 내가 생성해서 가지고 있어야겠다
	// 4번: 너도 static이 되어야 쓰겄다.
	private static PersonManager manager = new PersonManager();
//	private static PersonManager manager;

	// 3번: 내가 만든 manager를 외부에서 쓸수는 있어야하니 접근자를 만들어야겠다!
	// 접근자는 결국 인스턴스를 통해서만 접근이 가능해! -> 외부에서 인스턴스를 만들순 없어
	// static 키워드를 통해 미리 메모리에 올린다. -> static 영역은 non-static를 쓸 수 없다
	public static PersonManager getManager() {
//		if(manager == null) {
//			manager = new PersonManager();
//		}
		return manager;
	}

	// 메서드 CRUD
	// 추가 기능 (반환타입 1. void, 2. boolean)
	public void addPerson(Person p) {
		// size는 실제로 들어갈 위치도 의미하므로 넣고 증가 시킨다.
//		arr[size] = p;
//		size += 1;
		// 위의 코드와 동일하게 동작함
//		arr[size++] = p; 

		// 막 넣다가 보면 무슨일? -> 배열의 크기를 벗어나버려 ㅠ
//		if(size < MAX_SIZE) {
//			arr[size++] = p;
//			System.out.println("잘들어갔어!");
//		}else {
//			System.out.println("아닌데 넣을 수 없는데?");
//		}
		
		// else 안쓰고 표현 가능?
		if (size < MAX_SIZE) {
			arr[size++] = p;
			System.out.println("잘들어갔어!");
			return;
		}
		System.out.println("아닌데 넣을 수 없는데?");
		//return;
	}
	// 조회
	//조회는 두가지!
	//전제 조회(아래는 너무 심플해 없는 null도 다 와버려)
//	public Person[] getAll() {
//		return arr;
//	}
	
	public Person[] getAll() {
		//arr을 size에 맞게 복사를 해야겠다
		Person[] tmp = new Person[size];
		for(int i =0; i<size; i++ ) {
			tmp[i] = arr[i];
		}
		///////////////////////////////
		/// 아래도 같은건데 사실은 위에 코드처럼 동작함
//		Person[] tmp2 = Arrays.copyOf(arr, size);
		return tmp;
	}
	
	
	
	//상세 조회 -> 검색(이름을 통한 조회)
	//조회한 결과가 여러개라면....
//	public Person[]
	//우리는 지금 딱한개만 있다 고유한것을 검색한다 라고 가정 (동명이인은 없다라고 가정)
	public Person search(String name) {
		for(int i = 0 ; i<size; i++) {
			Person tmp = arr[i];
			if(tmp.getName().equals(name)) {
//			if(name.equals(tmp.getName())) {  //순서 중요할지도 모르겠다
				return tmp;
			}
		}//검색 for
		
		return null;
	}
	

	// 수정 (반환타입 2가지 1. void, 2. boolean)
	// 이름이 고유하다고 했으니까...
	public boolean updatePerson(Person p) {
		for(int i = 0 ; i<size; i++) {
			Person tmp = arr[i];
			if(tmp.getName().equals(p.getName())) {
				//p라고 하는 인스턴스가 완벽한 모든 정보를 가지고 있따.
//				tmp = p;	//이거슨 안된다. 이유 생각해보기 메모리 구조로
				arr[i] = p;
				
				//p에는 수정하고 싶은 정보만 있다.
//				arr[i].setAge(p.getAge());
//				arr[i].setHungry(p.isHungry());
				return true;
			}
		}
		
		return false;
	}
	
	
	// 삭제 ->여러개를 한방에 삭제할 수도 있지만 잘없음
	//보통은 고유한것을 이용해서 한개만 삭제하는 것이 대부분
	public void remove(String name) {
		//삭제를 하려면
		//1. 앞으로 밀착!(해보기)
		for(int i = 0; i<size; i++) {
			if(arr[i].getName().equals(name)) {
				//반복문을 수행하면서 땡겨오기!
//				for(int j = i; j <)
				//코드를 짜는 범위에 따라서 j 가 달라질도 모르겠다.
			}
		}
		//2. 맨뒤에서 가져오기(순서가 중요치 않다면)
		for(int i = 0; i<size; i++) {
			if(arr[i].getName().equals(name)) {
//				arr[i] = arr[size-1];
//				size -= 1;
				
				arr[i] = arr[--size];
			}
		}
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
