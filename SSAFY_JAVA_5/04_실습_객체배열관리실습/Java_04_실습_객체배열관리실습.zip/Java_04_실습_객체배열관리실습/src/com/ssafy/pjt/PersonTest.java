package com.ssafy.pjt;

public class PersonTest {
	public static void main(String[] args) {
//		PersonManager pm = new PersonManager();
		PersonManager pm = PersonManager.getManager();
		PersonManager pm2 = PersonManager.getManager();
		
		Person p = new Person("Yang", 45, "ISTP", false);
		pm.addPerson(p);
		
		
//		for(Person tmp: pm.getAll() ) {
//			System.out.println(tmp.toString());
////			System.out.println(tmp);
//		}
		
//		System.out.println(pm.search(null));
		//서울 16반 강형순님 명예
		Person p2 = new Person("Yang", 45, "ISTP", true);
		
		pm.updatePerson(p2);
		
		System.out.println(pm.search("Yang"));
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
