package modifier03_default2;

import modifier03_default.Person;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person();
		
//		p.age = 100; //패키지가 달라서 접근할 수 없다.
//		p.info();
	}
}
