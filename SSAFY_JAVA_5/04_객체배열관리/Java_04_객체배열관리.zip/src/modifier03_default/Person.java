package modifier03_default;

//(default) : 같은 패키지 안에서 접근이 가능하다.
public class Person {
	String name;
	int age;

	void info() {
		this.name = "Yang"; // name 내부에 있으니 접근이 가능하다!
	}
}
