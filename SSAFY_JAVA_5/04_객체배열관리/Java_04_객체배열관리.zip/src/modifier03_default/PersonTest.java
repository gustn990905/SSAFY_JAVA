package modifier03_default;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person();
		
		p.age = 100; //같은 패키지 이므로 접근이 가능하다.
		p.info();
	}
}
