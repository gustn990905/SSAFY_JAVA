package modifier04_protected;

//protected : 같은 패키지 안에서 접근이 가능하다. / 상속이면 다른패키지도 가능
public class Person {
	protected String name;
	protected int age;

	protected void info() {
		this.name = "Yang"; // name 내부에 있으니 접근이 가능하다!
	}
}
