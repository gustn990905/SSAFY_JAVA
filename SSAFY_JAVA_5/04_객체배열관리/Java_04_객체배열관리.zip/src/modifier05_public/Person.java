package modifier05_public;

//public : 접근 가넝
public class Person {
	public String name;
	public int age;

	public void info() {
		this.name = "Yang"; // name 내부에 있으니 접근이 가능하다!
	}
}
