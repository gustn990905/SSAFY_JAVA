package modifier07_object_array;

public class PersonManager {
	//회원 목록을 가지고 있고 //임시
	private Person[] arr = new Person[100]; 
	
	//접근자
	public Person[] getArr() {
		return arr;
	}
	
	//싱글턴 패턴
	private static PersonManager manager = new PersonManager();
	
	//외부에서 생성이 불가능하게 만들어야 한다.
	private PersonManager() {
		// TODO Auto-generated constructor stub
	}
	//접근자 생성 -> static
	public static PersonManager getManager() {
		return manager;
	}
	
	
	//회원에 대한 CRUD 기능을 수행할 수 있는 클래스
	
}
