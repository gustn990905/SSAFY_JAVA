package modifier07_object_array;


//private : 같은 클래스 내부에서만 접근이 가능하다.
public class Person {
	//외부에서 접근이 불가능하다.
	private String name;
	private int age;
	private String myName;
	private boolean homework;
	
	
	//기본생성자
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	//필드가 private 이라서 나이를 바꿀 수 없어
	//메서드를 하나 수정해주자
//	public void updateAge(int age) {
//		this.age = age;
//	}
	//관례적으로 필드를 수정할 때는 setXXXX라는 이름으로 만든다.
	//설정자
	public void setAge(int age) {
		//코드를 작성할 수 있죠!
		if(age < 0) {
			System.out.println("음수는 나이가 될 수 있나?");
		} else if(age >= 200) {
			System.out.println("혹시 흡혈귀?");
		} else {
			this.age = age;
		}
		
	}
	
	//접근자 getXXXXXX
	public int getAge() {
		return age;
	}
	
	
	public String getMyName() {
		return myName;
	}

	public boolean isHomework() {
		return homework;
	}

	public void setHomework(boolean homework) {
		this.homework = homework;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
