package modifier07_object_array;

public class Test {
	public static void main(String[] args) {
//		PersonManager pm = new PersonManager();
		
//		PersonManager pm2 = new PersonManager();
		
		PersonManager pm = PersonManager.getManager();
		PersonManager pm2 = PersonManager.getManager();
		PersonManager pm3 = PersonManager.getManager();
	}
}
