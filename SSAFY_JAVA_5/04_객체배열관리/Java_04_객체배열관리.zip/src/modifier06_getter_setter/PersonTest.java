package modifier06_getter_setter;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person(); //기본 생성자를 통해서 생성하면 
		
		Person p2 = new Person("Yang", 20);
		
//		p2.updateAge(30);
		
		p2.setAge(30);
		System.out.println(p2.getAge());
		
	}
}
