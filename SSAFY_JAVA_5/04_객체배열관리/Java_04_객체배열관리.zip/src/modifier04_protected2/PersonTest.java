package modifier04_protected2;

import modifier04_protected.Person;

public class PersonTest extends Person{
	public static void main(String[] args) {
		Person p = new Person();
		
//		p.age = 100; //같은 패키지 이므로 접근이 가능하다.
//		p.info();
		
		PersonTest pt = new PersonTest();
		pt.age = 100;
		pt.info();
		
	}
}
