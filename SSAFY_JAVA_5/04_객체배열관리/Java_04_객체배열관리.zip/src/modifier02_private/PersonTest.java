package modifier02_private;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person();
		
//		p.age = 100; //외부에서 접근이 불가하다.
//		p.info();
	}
}
