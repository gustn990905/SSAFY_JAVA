package modifier02_private;


//private : 같은 클래스 내부에서만 접근이 가능하다.
public class Person {
	private String name;
	private int age;
	
	private void info() {
		this.name = "Yang"; //name 내부에 있으니 접근이 가능하다!
	}
}
