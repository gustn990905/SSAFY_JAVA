package pkg1;

import java.util.Date;

import pkg1.pkg2.Pack;
//import pkg1.pkg2.pkg3.Pack;
class Pack1 {
	
}

class Pack2 {
	
}

class Pack3 {
	
}


public class PackTest {
	
//	class PackTmp{
//		
//	}
//	
	public static void main(String[] args) {
		Pack p = new Pack();
		System.out.println(p.pkg);
		
		pkg1.pkg2.pkg3.Pack p2 = new pkg1.pkg2.pkg3.Pack();
		System.out.println(p2.pkg);
		
		Date date;
	}
}
