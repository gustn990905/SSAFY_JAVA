package fileio03_CharacterStream;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharacterStreamTest02 {
	public static void main(String[] args) {
		try (FileReader fis = new FileReader("big_input.txt");
				FileWriter fos = new FileWriter("big_input_copy2.txt");) {
			int c; //문자를 전달할 크기
			char[] buffer = new char[100];
			while ((c = fis.read(buffer)) != -1) {
				fos.write(buffer, 0, c);
			}
		} catch (FileNotFoundException e) {
			System.out.println("파일 없음 이슈");
		} catch (IOException e) {
			System.out.println("더큰 통로 입출력 이슈");
		}
	}
}
