package fileio03_CharacterStream;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharacterStreamTest01 {
	public static void main(String[] args) {
		try (FileReader fis = new FileReader("big_input.txt");
				FileWriter fos = new FileWriter("big_input_copy.txt");) {
			int c; //문자를 전달할 크기
			while ((c = fis.read()) != -1) {
				fos.write(c);
			}
		} catch (FileNotFoundException e) {
			System.out.println("파일 없음 이슈");
		} catch (IOException e) {
			System.out.println("더큰 통로 입출력 이슈");
		}
	}
}
