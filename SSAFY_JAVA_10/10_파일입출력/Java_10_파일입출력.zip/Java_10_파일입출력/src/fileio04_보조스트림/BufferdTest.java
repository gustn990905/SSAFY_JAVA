package fileio04_보조스트림;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferdTest {
	public static void main(String[] args) {
		method1();
		method2();
	}

	public static void method1() {
		try (FileReader fis = new FileReader("big_input.txt");
				FileWriter fos = new FileWriter("big_input_copy3.txt");) {
			long start = System.nanoTime();
			int c; // 문자를 전달할 크기
			while ((c = fis.read()) != -1) {
				fos.write(c);
			}
			long end = System.nanoTime();
			System.out.println("노드스트림 이용 : " + (end - start));
		} catch (FileNotFoundException e) {
			System.out.println("파일 없음 이슈");
		} catch (IOException e) {
			System.out.println("더큰 통로 입출력 이슈");
		}
	}

	public static void method2() {
		try (BufferedReader br = new BufferedReader(new FileReader("big_input.txt"));
				BufferedWriter bw = new BufferedWriter(new FileWriter("big_input_copy4.txt"));) {
			long start = System.nanoTime();
			String line;
			while ((line = br.readLine()) != null) {
				bw.write(line);
				bw.newLine();
			}
			long end = System.nanoTime();
			System.out.println("보조스트림 이용 : " + (end - start));
		} catch (

		FileNotFoundException e) {
			System.out.println("파일 없음 이슈");
		} catch (IOException e) {
			System.out.println("더큰 통로 입출력 이슈");
		}
	}
}
