package fileio02_ByteStream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamTest02 {
	public static void main(String[] args) {
		// try with resources: 통로가 try문이 끝나면 알아서 close() 호출되도록!
		try (FileInputStream fis = new FileInputStream("dog.jpg");
				FileOutputStream fos = new FileOutputStream("dog-copy2.jpg");) {
			int b; // byte를 담을 변수
			while ((b = fis.read()) != -1) {
				fos.write(b);
			}
		} catch (FileNotFoundException e) {
			System.out.println("파일 없음 이슈");
		} catch (IOException e) {
			System.out.println("더큰 통로 입출력 이슈");
		}

	}
}
