package fileio05_객체직렬화;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectInputOutputTest {
	public static void main(String[] args) {
		
		Person p = new Person("Yang", 45);
		
		//실제 파일 저장 -> 직렬화
//		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("person.txt"))){
//			oos.writeObject(p);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		
		//실제 파일이 있고 읽어서 객체로 다시 바꾸자 -> 역직렬화
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("person.txt"));){
			Object obj = ois.readObject();
			System.out.println(obj); //동적바인딩에 의해서 사람의 정보가 출력이 되었다!
			
			if(obj instanceof Person pp) {
				Person ppp = (Person)obj;
				System.out.println(pp);
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
