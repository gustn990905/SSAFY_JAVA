package fileio05_객체직렬화;

import java.io.Serializable;

//자바 빈의 형태
public class Person implements Serializable {
	//UID 작성하지 않으면 컴파일러가 알아서 자동으로 넣어버려
	/**
	 * 테스트용
	 */
	private static final long serialVersionUID = 10_000_000_000L;

	
	private String name;
	private int age;
	
	public Person() {
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
}
